<?php

/**
 * August 1, 2012
 *
 * Jeff Bickart
 * Twitter: @bickart
 * Blog: http://sugarcrm-dev.blogspot.com/
 *
 * The following is a example of usage of the tincheck.com web-service to test the ValidateTinName
 * function.
 *
 * This example utilizes NuSoap which can be downloaded from 
 * http://sourceforge.net/projects/nusoap/
 *
 */

/* Turn off PHP errors */
ini_set("display_errors", "0");
error_reporting(E_ALL);

chdir(realpath(dirname(__FILE__)));
require_once('nusoap-0.9.5/lib/nusoap.php');

/* BEGIN TINCHECK */
class TinNameClass
{
    public $TIN;
    public $LName;
    protected  $FName;
    protected $Encryption;


    function TinNameClass($tin = "", $lname = "", $fname = "", $encryption = "")
    {
        $this->setEncryption($encryption);
        $this->setFName($fname);
        $this->setLName($lname);
        $this->setTIN($tin);
    }

    public function setEncryption($Encryption)
    {
        $this->Encryption = $Encryption;
    }

    public function getEncryption()
    {
        return $this->Encryption;
    }

    public function setFName($FName)
    {
        $this->FName = $FName;
    }

    public function getFName()
    {
        return $this->FName;
    }

    public function setLName($LName)
    {
        $this->LName = $LName;
    }

    public function getLName()
    {
        return $this->LName;
    }

    public function setTIN($TIN)
    {
        $this->TIN = $TIN;
    }

    public function getTIN()
    {
        return $this->TIN;
    }
}

class UserClass
{
    protected $UserID;
    protected $UserLogin;
    protected $UserPassword;
    protected $UserEncryption;

    public function UserClass($userid = "", $userlogin = "", $userpassword = "", $userencryption = "")
    {
        $this->setUserID($userid);
        $this->setUserLogin($userlogin);
        $this->setUserPassword($userpassword);
        $this->setUserEncryption($userencryption);
    }

    public function setUserEncryption($UserEncryption)
    {
        $this->UserEncryption = $UserEncryption;
    }

    public function getUserEncryption()
    {
        return $this->UserEncryption;
    }

    public function setUserID($UserID)
    {
        $this->UserID = $UserID;
    }

    public function getUserID()
    {
        return $this->UserID;
    }

    public function setUserLogin($UserLogin)
    {
        $this->UserLogin = $UserLogin;
    }

    public function getUserLogin()
    {
        return $this->UserLogin;
    }

    public function setUserPassword($UserPassword)
    {
        $this->UserPassword = $UserPassword;
    }

    public function getUserPassword()
    {
        return $this->UserPassword;
    }
}

function getProxy()
{
    $wsdlUri = 'https://www.tincheck.com/pvsws/pvsservice.asmx?WSDL';

    $client = new nusoap_client($wsdlUri, true);
    $client->timeout = 500;
    $client->response_timeout = 500;

    $err = $client->getError();
    if ($err)
        die("Soap client constructor err.. check wsdl url");

    $client->setDebugLevel(9);

    return $client->getProxy();
}

function checkForErrors($client)
{

    $err = $client->getError();
	
    if ($err) {
	
        print_r($err);
        die("\n");
    }

}

/* tell users how to use this program */

try {
    /* Obtain a Proxy to the Tincheck Service */
    $proxy = getProxy();
    checkForErrors($proxy);

    /* We are going to do validate the tin name */
    $TinName = new TinNameClass('920940167', 'atta');

    /* setup our User Account for the accessing TinCheck */
    $CurUser = new UserClass('','will@limitlessebooks.com','Faith123');

    $result = $proxy->ValidateTinName(array('TinName' => $TinName, 'CurUser' => $CurUser));
    checkForErrors($proxy);
    if ($result)
        print_r($result);
} catch (Exception $e) {
    print_r($e);
}
checkForErrors($proxy);

/* Display the actual XML that we sent to tincheck.com */
echo "request \n";
print_r($proxy->request);
echo "\n\n";

echo "response \n";
/* Display the actual XML that we received from tincheck.com */
print_r($proxy->response);
echo "\n";

?>
